<?php
/**
 * Register all actions and filters for the plugin.
 *
 * @package    Tender_PO_Management
 * @subpackage Tender_PO_Management/includes
 * @since      1.0.0
 */

// If this file is called directly, abort.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Register all actions and filters for the plugin.
 *
 * Maintain a list of all hooks that are registered throughout
 * the plugin, and register them with the WordPress API. Call the
 * run function to execute the list of actions and filters.
 *
 * @package    Tender_PO_Management
 * @subpackage Tender_PO_Management/includes
 * @since      1.0.0
 */
class TPM_Loader {

	/**
	 * The array of actions registered with WordPress.
	 *
	 * @since  1.0.0
	 * @var    array<int, array{hook: string, component: object|string, callback: string, priority: int, accepted_args: int}>
	 */
	protected array $actions = array();

	/**
	 * The array of filters registered with WordPress.
	 *
	 * @since  1.0.0
	 * @var    array<int, array{hook: string, component: object|string, callback: string, priority: int, accepted_args: int}>
	 */
	protected array $filters = array();

	/**
	 * Add a new action to the collection to be registered with WordPress.
	 *
	 * @since 1.0.0
	 * @param string        $hook          The name of the WordPress action that is being registered.
	 * @param object|string $component     A reference to the instance of the object or class name on which the action is defined.
	 * @param string        $callback      The name of the function definition on the $component.
	 * @param int           $priority      Optional. The priority at which the function should be fired. Default 10.
	 * @param int           $accepted_args Optional. The number of arguments that should be passed to the $callback. Default 1.
	 * @return void
	 */
	public function add_action( string $hook, object|string $component, string $callback, int $priority = 10, int $accepted_args = 1 ): void {
		$this->actions = $this->add( $this->actions, $hook, $component, $callback, $priority, $accepted_args );
	}

	/**
	 * Add a new filter to the collection to be registered with WordPress.
	 *
	 * @since 1.0.0
	 * @param string        $hook          The name of the WordPress filter that is being registered.
	 * @param object|string $component     A reference to the instance of the object or class name on which the filter is defined.
	 * @param string        $callback      The name of the function definition on the $component.
	 * @param int           $priority      Optional. The priority at which the function should be fired. Default 10.
	 * @param int           $accepted_args Optional. The number of arguments that should be passed to the $callback. Default 1.
	 * @return void
	 */
	public function add_filter( string $hook, object|string $component, string $callback, int $priority = 10, int $accepted_args = 1 ): void {
		$this->filters = $this->add( $this->filters, $hook, $component, $callback, $priority, $accepted_args );
	}

	/**
	 * A utility function that is used to register the actions and hooks into a single collection.
	 *
	 * @since  1.0.0
	 * @param  array         $hooks         The collection of hooks that is being registered.
	 * @param  string        $hook          The name of the WordPress filter that is being registered.
	 * @param  object|string $component     A reference to the instance of the object on which the filter is defined.
	 * @param  string        $callback      The name of the function definition on the $component.
	 * @param  int           $priority      The priority at which the function should be fired.
	 * @param  int           $accepted_args The number of arguments that should be passed to the $callback.
	 * @return array The collection of hooks that is registered with WordPress.
	 */
	private function add( array $hooks, string $hook, object|string $component, string $callback, int $priority, int $accepted_args ): array {
		$hooks[] = array(
			'hook'          => $hook,
			'component'     => $component,
			'callback'      => $callback,
			'priority'      => $priority,
			'accepted_args' => $accepted_args,
		);

		return $hooks;
	}

	/**
	 * Register the filters and actions with WordPress.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public function run(): void {
		foreach ( $this->filters as $hook ) {
			add_filter( $hook['hook'], array( $hook['component'], $hook['callback'] ), $hook['priority'], $hook['accepted_args'] );
		}

		foreach ( $this->actions as $hook ) {
			add_action( $hook['hook'], array( $hook['component'], $hook['callback'] ), $hook['priority'], $hook['accepted_args'] );
		}
	}
}
